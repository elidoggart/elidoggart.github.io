from pathlib import Path
import subprocess,re
p=Path(__file__).resolve().parent/'engine'/'doomgeneric';out=p.parent.parent/'web'
s=re.search(r'SRC_DOOM = (.*)',(p/'Makefile').read_text())[1].replace('doomgeneric_xlib.o','doomgeneric_browser.o')
cmd=['emcc']+[x.replace('.o','.c') for x in s.split()]+['-O2','-DFEATURE_SOUND','-DDOOMGENERIC_RESX=320','-DDOOMGENERIC_RESY=200','-Wno-incompatible-pointer-types','-Wno-int-conversion','-sASYNCIFY','-sALLOW_MEMORY_GROWTH','-sEXPORTED_RUNTIME_METHODS=FS,callMain,HEAPU8','-sINVOKE_RUN=0','-sFORCE_FILESYSTEM=1','-sEXIT_RUNTIME=0','-o',str(out/'doom-runtime.js')]
subprocess.run(cmd,cwd=p,check=True)
