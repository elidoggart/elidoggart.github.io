Wireframe Doom — complete corresponding engine and browser source

Upstream: https://github.com/ozkl/doomgeneric
Upstream revision: e257a09527062bfb986b6e5e0780839b6cbd5b71

Build with Python 3 and Emscripten 4.0.10:
  source /path/to/emsdk/emsdk_env.sh
  python3 build.py
Place the original Doom shareware doom1.wad in web/ (game data is not included in this source archive).
  python3 -m http.server 8080 --directory web
Open http://localhost:8080/doom.html

The engine's original simulation is unchanged. Surface IDs are written alongside its framebuffer; surface boundaries become black lines. Original sprite silhouettes and quantized detail become red lines. The HUD is browser text fed from original player state. Original PCM effects play through Web Audio; original MUS compositions are played by a simple synthesizer (not original OPL instrumentation). Original save slots persist in localStorage. WASM uses Asyncify for Doom's waits.

Modified files: r_draw.c, r_main.c, r_segs.c, r_plane.c, r_things.c, v_video.c, i_sound.c, m_config.c, g_game.c. Added wireframe.h, doomgeneric_browser.c and web bridge. GPL-2.0-or-later; see engine/LICENSE. Game data remains separately licensed by id Software.
