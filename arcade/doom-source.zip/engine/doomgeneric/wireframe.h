#ifndef WIREFRAME_H
#define WIREFRAME_H
#include <stdint.h>
extern uint32_t wf_surface[320*200],wf_current,wf_sprite;
extern unsigned char *I_VideoBuffer;
#define WF_TAG(ptr) (wf_surface[(ptr)-I_VideoBuffer]=wf_current)
void WF_Clear(void);
#endif
