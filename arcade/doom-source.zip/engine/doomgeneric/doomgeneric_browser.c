#include <emscripten.h>
#include <string.h>
#include <stdio.h>
#include "doomgeneric.h"
#include "wireframe.h"
#include "doomstat.h"
#include "d_event.h"
#include "d_items.h"
extern boolean menuactive;
#include "i_sound.h"
#include "w_wad.h"
#include "z_zone.h"
uint32_t wf_surface[320*200],wf_current,wf_sprite;
static uint32_t output[320*200];
void WF_Clear(void){memset(wf_surface,0,sizeof(wf_surface));wf_sprite=0;}
static int queue[256],readpos,writepos;
EMSCRIPTEN_KEEPALIVE int doom_menu(void){return menuactive;}
EMSCRIPTEN_KEEPALIVE void doom_pause(void){if(gamestate==GS_LEVEL&&!menuactive){extern void M_StartControlPanel(void);M_StartControlPanel();}}
EMSCRIPTEN_KEEPALIVE void doom_key(int key,int down){queue[writepos++&255]=key|(down<<8);}
EMSCRIPTEN_KEEPALIVE void doom_mouse(int dx){event_t e={ev_mouse,0,dx,0};D_PostEvent(&e);}
int DG_GetKey(int *down,unsigned char *key){if(readpos==writepos)return 0;int k=queue[readpos++&255];*down=k>>8;*key=k&255;return 1;}
void DG_Init(void){}
void DG_SetWindowTitle(const char *s){}
void DG_SleepMs(uint32_t ms){emscripten_sleep(ms);}
uint32_t DG_GetTicksMs(void){return emscripten_get_now();}
static int luminance(uint32_t c){return (((c>>16)&255)*3+((c>>8)&255)*6+(c&255))/10;}
void DG_DrawFrame(void){
 for(int y=0;y<200;y++)for(int x=0;x<320;x++){
  int i=y*320+x;uint32_t id=wf_surface[i];int edge=0,red=0;
  if(gamestate==GS_LEVEL && id==0x40000000u){red=1;edge=luminance(DG_ScreenBuffer[i])>40;}
  else if(menuactive && gamestate==GS_LEVEL && y<168){edge=0;}
  else if(gamestate==GS_LEVEL && !automapactive && y<168 && id){
   if(x<319&&id!=wf_surface[i+1])edge=1;
   if(y<167&&id!=wf_surface[i+320])edge=1;
   if(id&0x80000000u){red=1;int l=luminance(DG_ScreenBuffer[i])/55;
    if(x<319 && wf_surface[i+1]==id && l!=luminance(DG_ScreenBuffer[i+1])/55)edge=1;
    if(y<167 && wf_surface[i+320]==id && l!=luminance(DG_ScreenBuffer[i+320])/55)edge=1;
   }
  }else{
   int l=luminance(DG_ScreenBuffer[i]);
   if(x<319&&abs(l-luminance(DG_ScreenBuffer[i+1]))>40)edge=1;
   if(y<199&&abs(l-luminance(DG_ScreenBuffer[i+320]))>40)edge=1;
   red=((DG_ScreenBuffer[i]>>16)&255)>((DG_ScreenBuffer[i]>>8)&255)*1.4;
  }
  output[i]=edge?(red?0xff3631c7:0xff212423):0xffffffff;
 }
 EM_ASM({Module.renderFrame($0,320,200);},output);
 player_t *p=&players[consoleplayer];int a=weaponinfo[p->readyweapon].ammo;int keys=0;for(int k=0;k<6;k++)if(p->cards[k])keys|=1<<k;
 EM_ASM({Module.updateHUD($0,$1,$2,$3,$4,$5);},p->health,p->armorpoints,a<NUMAMMO?p->ammo[a]:-1,keys,gamemap,gamestate==GS_LEVEL);
}
static boolean sndinit(boolean b){return 1;}static void noop(void){}
static int lump(sfxinfo_t *s){char n[12];snprintf(n,12,"ds%s",s->name);return W_GetNumForName(n);}
static void params(int c,int v,int s){EM_ASM({Module.soundParams?.($0,$1,$2);},c,v,s);}
static int startsound(sfxinfo_t *s,int c,int v,int sep){unsigned char *d=W_CacheLumpNum(s->lumpnum,PU_CACHE);int len=W_LumpLength(s->lumpnum);if(len>8){int rate=d[2]|d[3]<<8;EM_ASM({Module.playSound($0,$1,$2,$3,$4,$5);},d+8,len-8,rate,c,v,sep);}return c;}
static void stopsound(int c){EM_ASM({Module.stopSound?.($0);},c);}
static boolean playing(int c){return EM_ASM_INT({return Module.soundPlaying?.($0)?1:0;},c);}
static snddevice_t devices[]={SNDDEVICE_SB};
sound_module_t DG_sound_module={devices,1,sndinit,noop,lump,noop,params, startsound,stopsound,playing,NULL};
static boolean musicinit(void){return 1;}static void volume(int v){EM_ASM({Module.musicVolume=$0/127;},v);}static void *regsong(void*d,int n){EM_ASM({Module.registerMusic($0,$1);},d,n);return d;}static void unreg(void*p){}static void song(void*p,boolean l){EM_ASM({Module.startMusic();});}static boolean musicplaying(void){return 1;}
static void stopmusic(void){EM_ASM({Module.stopMusic();});}
music_module_t DG_music_module={devices,1,musicinit,noop,volume,noop,noop,regsong,unreg,song,stopmusic,musicplaying,noop};
int main(int argc,char **argv){doomgeneric_Create(argc,argv);emscripten_set_main_loop(doomgeneric_Tick,0,1);return 0;}
